make
make run2
diff shang.O2.completeoutput shang.O2.out > o2res.txt


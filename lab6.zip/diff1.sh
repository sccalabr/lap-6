make
make run1
diff shang.O1.completeoutput shang.O1.out > o1res.txt

